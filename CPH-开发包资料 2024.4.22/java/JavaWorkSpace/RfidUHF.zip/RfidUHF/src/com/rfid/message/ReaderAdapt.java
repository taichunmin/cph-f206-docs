package com.rfid.message;

public abstract class ReaderAdapt {
	
}
