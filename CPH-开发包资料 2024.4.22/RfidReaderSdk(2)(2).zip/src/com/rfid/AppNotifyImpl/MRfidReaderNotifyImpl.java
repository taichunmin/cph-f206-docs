package com.rfid.AppNotifyImpl;

import com.rfid.reader.AppNotify;

public class MRfidReaderNotifyImpl implements AppNotify {
	/*
	 * EN_TLV_ATTR_CODE_IDLE = 0x00, //��Ч���ݸ�ʽ
    EN_TLV_ATTR_CODE_EPC = 0x01,    //EPC����
    EN_TLV_ATTR_CODE_USER = 0x02,   //user��������
    EN_TLV_ATTR_CODE_RESERVE = 0x03,//���������
    EN_TLV_ATTR_CODE_TEMPERATURE = 0x04,    //�¶�����
    EN_TLV_ATTR_CODE_RSSI = 0x05,
    EN_TLV_ATTR_CODE_FLUSH_NOW_TIME = 0x06,
    EN_TLV_ATTR_CODE_STATUS = 0x07,
    EN_TLV_ATTR_TAG_OPERATION_INFO = 0x08,  //mambank addr[2] length[2]
    EN_TLV_ATTR_CODE_PASSWORD = 0x10,
    EN_TLV_ATTR_SOFTWARE_VERSION = 0x20,
    EN_TLV_ATTR_DEVICE_TYPE = 0x21,
    EN_TLV_ATTR_WORKING_PARAM = 0x23,
    EN_TLV_ATTR_TRANSPORT_PARAM = 0x24,
    EN_TLV_ATTR_ADVANCE_PARAM = 0x25,
    EN_TLV_ATTR_SIGNLE_PARAM = 0x26,
    EN_TLV_ATTR_WRITE_TAG = 0x27,
    EN_TLV_ATTR_TAG_READ_TAG =0x28,
    EN_TLV_ATTR_CODE_SINGLE_TAG_DATA = 0x50
	 * */
	private static final byte TLV_ONE_TAG_DATA = 0x50;
	private static final byte TLV_EPC = 0x01;
	//�Ӳ�������ʼλ�ò��ҹ涨��TLV������������򷵻�-1
	public int GetTlvPosition(byte[] message, int startIndex,int paramLen,byte tlvType)
	{
		int pos = -1;
		int index = 0;
		for (index = 0; index < paramLen;index++)
		{
			if (message[startIndex] == tlvType)
			{
				pos = startIndex;
				break;
			}
			else
			{
				index = index + message[startIndex+1] + 2;
				startIndex = startIndex + message[startIndex+1] + 2;
			}
		}
		return pos;
	}
	
	
	@Override
	public int NotifyRecvTags(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		int start_tlv_pos = startIndex + 8;
		int param_len = 0;
		int tag_tlv_pos = 0;
		int EPC_Tlv = 0;
		param_len = message[startIndex+6] & 0xFF;
		param_len = param_len << 8;
		param_len = message[startIndex+7] & 0xFF;
		tag_tlv_pos = GetTlvPosition(message,start_tlv_pos,param_len,TLV_ONE_TAG_DATA);
		if (tag_tlv_pos < 0)
		{
			//��ǩ���ݲ����ڣ�����Ҫ����
			return -1;
		}
		
		//��ȡ��TLV����ʼλ��
		start_tlv_pos = tag_tlv_pos + 2;
		param_len = message[start_tlv_pos + 1];
		EPC_Tlv = GetTlvPosition(message,start_tlv_pos,param_len,TLV_EPC);
		if (EPC_Tlv < 0)
		{
			//EPC ���ݲ�����
			return -2;
		}
		
		System.out.print("�ϴ���ǩ���豸ID:"+Integer.toHexString(message[startIndex+3] & 0xFF) +" " + Integer.toHexString(message[startIndex+4] & 0xFF));
		System.out.print("   ��ȡ���ı�ǩ����:");
		for (int iIndex = 0; iIndex < (message[EPC_Tlv+1] & 0xFF) ;iIndex++)
		{
			System.out.print( String.format("%02X ", message[EPC_Tlv+2+iIndex]));
		}
		System.out.println();
		return 0;
	}

	@Override
	public int NotifyStartInventory(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyStopInventory(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyReset(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyReadTagBlock(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyWriteTagBlock(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyLockTag(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyKillTag(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int NotifyInventoryOnce(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		return 0;
	}

}
