package com.rfid.reader;

import java.io.IOException;

import com.rfid.AppNotifyImpl.GeneralReaderNotifyImpl;
import com.rfid.AppNotifyImpl.MRfidReaderNotifyImpl;

public class MRfidReader extends RfidReader {
	private byte[] readerId = null;
	
	private final static byte MReader_Cmd_Reset = 0x10;
	private final static byte MReader_Notify_tag = (byte)0x80;
	public MRfidReader()
	{
		readerId = new byte[2];
		readerId[0] = 0;
		readerId[1] = 0;
	}
	
	private byte CaculateCheckSum(byte []message,int start_pos,int len)
	{
		long checksum = 0;
		int iIndex = 0;
		for (iIndex = 0;iIndex < len; iIndex++)
		{
			checksum += getUnsignedByte(message[start_pos+iIndex]);
		}
		checksum = ~checksum + 1;
		return (byte)(checksum & 0xFF);
	}

	private void FillLengthAndCheksum() {
		int indeedLen = sendIndex + 1 - 6;
		sendMsgBuff[6] = (byte)(indeedLen >> 8);
		sendMsgBuff[7] = (byte)indeedLen;
		sendMsgBuff[sendIndex] = CaculateCheckSum(sendMsgBuff, 0, sendIndex);
		++sendIndex;
	}
	
	private void BuildMessageHeader(byte commandCode) {
		// TODO Auto-generated method stub
		sendIndex = 0;
		sendMsgBuff[sendIndex++] = 'R';
		sendMsgBuff[sendIndex++] = 'F';
		sendMsgBuff[sendIndex++] = 0;
		sendMsgBuff[sendIndex++] = readerId[0];
		sendMsgBuff[sendIndex++] = readerId[1];
		sendMsgBuff[sendIndex++] = commandCode;
		//fill length zero
		sendMsgBuff[sendIndex++] = 0;
		sendMsgBuff[sendIndex++] = 0;
	}
	
	@Override
	public int Inventory() throws IOException {
		// TODO Auto-generated method stub
		if (null == transport)
		{
			return -1;
		}
		BuildMessageHeader((byte)0x21);
		FillLengthAndCheksum();
		transport.SendData(sendMsgBuff, sendIndex);
		return 0;
	}

	@Override
	public int InventoryOnce() throws IOException {
		// TODO Auto-generated method stub
		if (null == transport)
		{
			return -1;
		}
		BuildMessageHeader((byte)0x22);
		FillLengthAndCheksum();
		transport.SendData(sendMsgBuff, sendIndex);
		return 0;
	}

	@Override
	public int Stop() throws IOException {
		// TODO Auto-generated method stub
		if (null == transport)
		{
			return -1;
		}
		BuildMessageHeader((byte)0x23);
		FillLengthAndCheksum();
		transport.SendData(sendMsgBuff, sendIndex);
		return 0;
	}

	@Override
	public int Reset() throws IOException {
		// TODO Auto-generated method stub
		if (null == transport)
		{
			return -1;
		}
		BuildMessageHeader((byte)0x10);
		FillLengthAndCheksum();
		transport.SendData(sendMsgBuff, sendIndex);
		return 0;
	}

	@Override
	public int ReadTagBlock(byte membank, byte addr, byte len) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int WriteTagBlock(byte membank, byte addr, byte len, byte[] writtenData, int writeStartIndex)
			throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int LockTag(byte lockType) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int KillTag() throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int HandleRecv() throws IOException {
		// TODO Auto-generated method stub
		recvMsgLen = transport.ReadData(recvMsgBuff);
		HandleMessage();
		return 0;
	}

	@Override
	public void HandleMessage() {
		// TODO Auto-generated method stub
		byte []message = recvMsgBuff;
		byte checksum = 0;
		byte caculatedChecksum = 0;
		int buffPos = 0;
		int paramLen = 0;
		while (buffPos <= recvMsgLen - 9){
			if ( message[buffPos] != 'R' && message[buffPos+1] != 'F')
			{
				buffPos++;
			}
			
			paramLen = getUnsignedByte(message[buffPos+6]);
			paramLen = paramLen << 8;
			paramLen = paramLen += getUnsignedByte(message[buffPos+7]);
			if (paramLen > 255) {
				buffPos++;
				continue;
			}
			
			checksum = message[buffPos + paramLen + 8];
			caculatedChecksum = CaculateCheckSum(message,buffPos,paramLen+8);
			if (caculatedChecksum == checksum)
			{
				//У����յ���������ȷ������Ӧ��Ϣ
				NotifyMessageToApp(message, buffPos);
				//������ɺ������¸�����
				buffPos = buffPos + paramLen + 9;
			}
			else {
				++buffPos;
			}
		}
	}

	@Override
	protected void NotifyMessageToApp(byte[] message, int startIndex) {
		// TODO Auto-generated method stub
		MRfidReaderNotifyImpl appNotify = (MRfidReaderNotifyImpl)getAppNotify();
		if ( null == appNotify) {
			return;
		}
		if ( 1 == message[startIndex + 2])
		{
			switch(message[startIndex + 5]) {
			case MReader_Cmd_Reset:
				appNotify.NotifyReset(message, startIndex);
				break;
			}
		}
		else if (2 == message[startIndex + 2])
		{
			switch(message[startIndex+5])
			{
			case MReader_Notify_tag:
				appNotify.NotifyRecvTags(message, startIndex);
				break;
			}
		}
	}

	@Override
	public int RelayOperation(byte relayNo, byte operation_type, byte op_time) throws IOException {
		// TODO Auto-generated method stub
		int index = 0;
		if (null == transport)
		{
			return -1;
		}
		BuildMessageHeader((byte)0x4C);
		//Add TLV
		sendMsgBuff[sendIndex++] = 0x27;
		index = sendIndex++;
		sendMsgBuff[sendIndex++] = 0x00;
        if ( (relayNo & 0x01) != 0)
        {
        	sendMsgBuff[sendIndex++] = 1;
        	sendMsgBuff[sendIndex++] = operation_type;
        	sendMsgBuff[sendIndex++] = op_time;
        }
        if ((relayNo & 0x02) != 0)
        {
        	sendMsgBuff[sendIndex++] = 2;
        	sendMsgBuff[sendIndex++]= operation_type;
        	sendMsgBuff[sendIndex++] = op_time;
        }
		FillLengthAndCheksum();
		transport.SendData(sendMsgBuff, sendIndex);
		return 0;
	}

}
